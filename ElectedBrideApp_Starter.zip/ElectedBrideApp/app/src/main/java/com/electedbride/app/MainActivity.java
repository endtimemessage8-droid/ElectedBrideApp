package com.electedbride.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    int purple = Color.rgb(108,52,131);
    int gold = Color.rgb(247,220,111);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showHome();
    }

    TextView title(String text, int size) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextSize(size); t.setTextColor(Color.WHITE);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(20, 18, 20, 18);
        return t;
    }

    Button button(String text) {
        Button b = new Button(this);
        b.setText(text); b.setTextSize(15); b.setAllCaps(false);
        return b;
    }

    void base(String page) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(250,247,252));
        setContentView(root);
        TextView head = title("✝  ELECTED BRIDE\n" + page, 20);
        head.setBackgroundColor(purple);
        root.addView(head, new LinearLayout.LayoutParams(-1, -2));
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(16,16,16,10);
        ScrollView scroll = new ScrollView(this); scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        nav();
    }

    void nav() {
        LinearLayout n = new LinearLayout(this); n.setGravity(Gravity.CENTER);
        String[] names = {"Home","Bible","Messages","Videos","Favorites","Alerts"};
        View.OnClickListener[] ls = {
            v->showHome(), v->showBible(), v->showMessages(), v->showVideos(), v->showFavorites(), v->showAlerts()
        };
        for(int i=0;i<names.length;i++){ Button b=button(names[i]); final int j=i; b.setOnClickListener(ls[i]);
            n.addView(b,new LinearLayout.LayoutParams(0,60,1));
        }
        root.addView(n);
    }

    void addText(String s, int sp) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(Color.DKGRAY);
        t.setPadding(8,12,8,12); content.addView(t);
    }

    void showHome() {
        base("Bible Message App");
        addText("The Word Bride hath made herself ready.", 19);
        addText("📖 Daily Bible Verse\n\nప్రభువే ఆత్మ. ప్రభువుయొక్క ఆత్మయెక్కడ నుండునో అక్కడ స్వాతంత్యమునుండును.\n2 కొరింథీయులకు 3:17", 17);
        Button b=button("▶ Open YouTube Channel"); b.setOnClickListener(v->open("https://www.youtube.com/@Electedbride-wmb")); content.addView(b);
        addText("Welcome to ELECTED BRIDE — Bible verses, messages and videos in one place.", 16);
        Button settings=button("⚙ More / Settings"); settings.setOnClickListener(v->showSettings()); content.addView(settings);
    }

    void showBible() {
        base("Bible Verses / బైబిల్ వచనాలు");
        addText("🔎 Search verses",17);
        addText("యెహోవా నా కాపరి; నాకు కొదువలేదు.\nకీర్తనలు 23:1",17);
        addText("ప్రభువే ఆత్మ.\n2 కొరింథీయులకు 3:17",17);
        addText("యెహోవా ఇల్లు కట్టించనియెడల దాని కట్టువారి ప్రయాసము వ్యర్థమే.\nకీర్తనలు 127:1",17);
    }

    void showMessages() {
        base("Messages / సందేశాలు");
        addText("🎙️ Latest Messages",20);
        addText("Message 01\nWilliam Marrion Branham message\n▶ Listen / Watch",17);
        addText("Message 02\nBible Message\n▶ Listen / Watch",17);
        addText("Message 03\nThe Word Bride\n▶ Listen / Watch",17);
    }

    void showVideos() {
        base("YouTube Videos");
        addText("▶ Latest videos from @Electedbride-wmb",19);
        Button b=button("Open YouTube Channel"); b.setOnClickListener(v->open("https://www.youtube.com/@Electedbride-wmb")); content.addView(b);
        addText("మీ YouTube Shorts మరియు Videos ను ఇక్కడ చూపించడానికి తర్వాత YouTube integration జోడించవచ్చు.",16);
    }

    void showFavorites() {
        base("Favorites / ఇష్టమైనవి");
        addText("❤️ Saved Bible Verses",19);
        addText("మీరు ఇష్టమైన వచనాలను ఇక్కడ సేవ్ చేసుకోవచ్చు.",16);
        addText("❤️ Saved Messages",19);
        addText("మీకు నచ్చిన సందేశాలను ఇక్కడ ఉంచుకోవచ్చు.",16);
    }

    void showAlerts() {
        base("Notifications / నోటిఫికేషన్స్");
        addText("🔔 New Video\nకొత్త YouTube వీడియో అందుబాటులో ఉంది.",17);
        addText("📖 Daily Verse\nఈరోజు బైబిల్ వచనం చదవండి.",17);
        addText("🎙️ New Message\nకొత్త సందేశం జోడించబడింది.",17);
    }

    void showSettings() {
        base("More / Settings");
        addText("⚙ Settings",20);
        addText("🌐 Language — తెలుగు / English",17);
        addText("🔔 Notifications",17);
        addText("🌙 Dark Mode",17);
        addText("❤️ Favorites",17);
        addText("ℹ About ELECTED BRIDE",17);
        addText("🔗 Share App",17);
        addText("⭐ Rate the App",17);
        addText("Version 1.0",14);
    }

    void open(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch(Exception ignored) {}
    }
}

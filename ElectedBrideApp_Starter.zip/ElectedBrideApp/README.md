# ELECTED BRIDE – Bible Message App

Phone-friendly starter Android project assembled from the uploaded files.

Included:
- Home
- Bible Verses
- Messages
- YouTube
- Favorites
- Notifications
- More / Settings
- Telugu + English UI
- Direct link to the @Electedbride-wmb YouTube channel

Important:
This is still a starter project, not a Play Store-ready release. The project needs testing, production configuration, a privacy policy, final assets/content permissions, and a signed Android App Bundle (AAB) before publishing.

The original starter did not include Gradle wrapper files, so Android Studio may need to download/configure Gradle on first open.
